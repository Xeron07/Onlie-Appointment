<!DOCTYPE html>
<html lang="en">
<head>
  <title>Admin</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@8"></script>
</head>
<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">予約 Online</a>
    </div>
    <ul class="nav navbar-nav">
    <li onclick="window.location.replace('/home')"><a >Home</a></li>
      <li onclick="openUser()"><a>Users</a></li>
      <li onclick="openApp()"><a >Appointments</a></li>
      <li onclick="openNews()"><a >News</a></li>
      
      
    </ul>
  </div>
</nav>
  



<div class="container">

<div id="user" style="display:none">
</br>	
<input class="form-control" id="myInput1" type="text" placeholder="Search User..">
  <table class="table">
    <thead class="thead-light">
      <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Email</th>
        <th>Operation</th>
      </tr>
    </thead>
    <tbody id="myTable1">
     <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
			<td><?php echo e($user->userId); ?></td>
			<td><?php echo e($user->name); ?></td>
			<td><?php echo e($user->email); ?></td>
			<td><button type="button" class="btn btn-danger" onclick="deleteUserConfirm('<?php echo e($user->userId); ?>')">Delete</button></td>
		</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
</div>


<div id="app" style="display:none">
</br>
<input class="form-control" id="myInput2" type="text" placeholder="Search Appointment..">
  <table class="table">
    <thead class="thead-light">
      <tr>
        <th>ID</th>
        <th>Title</th>
        <th>Location</th>
        <th>Operation</th>
      </tr>
    </thead>
    <tbody id="myTable2">
     <?php $__currentLoopData = $apps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $app): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
			<td><?php echo e($app->aId); ?></td>
			<td><?php echo e($app->title); ?></td>
			<td><?php echo e($app->location); ?></td>
			<td><button type="button" class="btn btn-danger" onclick="deleteappConfirm('<?php echo e($app->aId); ?>')">Delete</button></td>
		</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>


</div>

<div id="news" style="display:none">
   <b style="font-size:120%">Title</b>
   <br/>
   <input class="form-control col-sm-3" style="width:20%" id="title" type="text">
   <br/>
   <br/>
   <b style="font-size:120%">Message</b>
   <textarea rows="7" cols="35" class="form-control" id="msg"></textarea>
   <br/>
   <button type="button" class="btn btn-success" onclick="newsPublish()">Publish</button>


</div>



</div>

 

</body>

<script type="text/javascript">
 var previous;

 $('document').ready(()=>{
    previous=$("#user");
    $("#user").css("display","block");
 });


 function openUser(){
       previous.css("display","none");
       previous.attr("class","");
       $("#user").css("display","block");
       previous=$("#user");
 }

 function openApp(){
         previous.css("display","none");
       $("#app").css("display","block");
       previous=$("#app");
}
       function openNews(){
         previous.css("display","none");
       $("#news").css("display","block");
       previous=$("#news");
 }

//bootstrap search //

$(document).ready(function(){
  $("#myInput1").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myTable1 tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput2").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myTable2 tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

function deleteUserConfirm(id){
	Swal.fire({
  title: 'Are you sure?',
  text: "You won't be able to revert this!",
  type: 'warning',
  showCancelButton: true,
  confirmButtonColor: '#3085d6',
  cancelButtonColor: '#d33',
  confirmButtonText: 'Yes, delete it!'
}).then((result) => {
  if (result.value) {
        deleteuser(id);  
}});

}

function deleteuser(id){
	 $.ajax({
           method:"POST",
           url:"/delete/user",
           data:{id:id},
           headers: {
             'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
           success:(result)=>{
             if(result.msg=="success"){
                       console.log(result.data);
                     Swal.fire("","User Deleted","success").then((result)=>{
                          location.reload();
                     });
                     
             }
           },
           error:(err)=>{
             //Swal.fire(err);
             console.log(err);
           }
        });
}
  




function deleteappConfirm(id){
	Swal.fire({
  title: 'Are you sure?',
  text: "You won't be able to revert this!",
  type: 'warning',
  showCancelButton: true,
  confirmButtonColor: '#3085d6',
  cancelButtonColor: '#d33',
  confirmButtonText: 'Yes, delete it!'
}).then((result) => {
  if (result.value) {
        deleteapp(id);  
}});

}

function deleteapp(id){
	 $.ajax({
           method:"POST",
           url:"/delete/appointment",
           data:{id:id},
           headers: {
             'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
           success:(result)=>{
             if(result.msg=="success"){
                       console.log(result.data);
                     Swal.fire("","Appointment Deleted","success").then((result)=>{
                          location.reload();
                     });
                     
             }
           },
           error:(err)=>{
             //Swal.fire(err);
             console.log(err);
           }
        });
}

function newsPublish(){
    var t=$("#title").val();
    var msg=$("#msg").val();

    $.ajax({
           method:"POST",
           url:"/news/upload",
           data:{title:t,msg:msg},
           headers: {
             'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
           success:(result)=>{
             if(result.msg=="success"){
                       console.log(result.data);
                     Swal.fire("","News Uploaded","success").then((result)=>{
                         
                     });
                     
             }
           },
           error:(err)=>{
             //Swal.fire(err);
             console.log(err);
           }
        });

}

</script>
</html>
